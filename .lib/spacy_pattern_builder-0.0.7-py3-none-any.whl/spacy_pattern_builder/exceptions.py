class TokensNotFullyConnectedError(Exception):
    pass


class DuplicateTokensError(Exception):
    pass


class TokenNotInMatchTokensError(Exception):
    pass


class FeaturesMissingFromPatternError(Exception):
    pass
